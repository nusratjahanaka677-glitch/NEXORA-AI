require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, name: "NEXORA AI", aiConfigured: Boolean(process.env.GEMINI_API_KEY) });
});

// Secure server-side AI endpoint. Requires the user's own Gemini API key.
// The UI remains usable in demo mode without a key.
app.post("/api/assistant", async (req, res) => {
  const prompt = String(req.body?.prompt || "").trim();
  if (!prompt) return res.status(400).json({ error: "Please enter a prompt." });
  if (!process.env.GEMINI_API_KEY) {
    return res.status(503).json({
      error: "AI engine is not connected yet.",
      detail: "Add a Gemini API key to .env on your own server, then restart NEXORA AI."
    });
  }
  try {
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + encodeURIComponent(process.env.GEMINI_API_KEY),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
      }
    );
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: "AI provider error", detail: data?.error?.message || "Request failed." });
    const answer = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("\\n") || "No response received.";
    res.json({ answer });
  } catch (_err) {
    res.status(500).json({ error: "Could not reach the AI provider. Please try again." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`NEXORA AI running on http://localhost:${port}`));
