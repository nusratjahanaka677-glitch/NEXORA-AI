const studios = {
 website:{title:"Website Studio",desc:"Plan and structure responsive websites, landing pages and portfolios.",icon:"▣",caps:["Business sites","Portfolio","E-commerce plan","Landing pages","HTML / CSS / JS"],notice:"This version saves a website project brief. A live site generator and hosting deployment connector are future integrations."},
 roblox:{title:"Roblox Creator Studio",desc:"Prepare Roblox avatar, clothing, character, map and Luau development briefs.",icon:"◈",caps:["Avatar design brief","Clothing concepts","Accessories","Map planning","Luau scripts"],notice:"This version creates briefs and planning notes. Roblox-compatible asset generation, Studio import and publishing need dedicated tools and Roblox permissions."},
 games:{title:"Universal Game Creator",desc:"Design game concepts, mechanics, levels, characters and development plans.",icon:"🎮",caps:["2D / 3D concepts","Open world","Level design","Game mechanics","Testing checklist"],notice:"A complete playable game needs a game engine and generated assets. This workspace prepares the project brief."},
 cartoon:{title:"Cartoon & Animation",desc:"Develop characters, stories, storyboards and animation plans.",icon:"✿",caps:["Character sheets","Storyboards","Scene plans","2D animation","Dialogue drafts"],notice:"Animation rendering requires a dedicated animation engine or external tool."},
 threeD:{title:"3D Studio",desc:"Plan 3D models, props, environments and export requirements.",icon:"⬡",caps:["3D characters","Props","Environment","Materials","Export plan"],notice:"Actual 3D modeling and rendering require a compatible 3D engine such as Blender."},
 media:{title:"Image & Video Studio",desc:"Prepare image prompts, visual concepts, shot lists and video scripts.",icon:"▧",caps:["Image prompts","Logo concepts","Video scripts","Shot lists","Visual direction"],notice:"Image and video generation need a connected generation provider; free quotas and watermarks vary."},
 coding:{title:"Coding Studio",desc:"Write, organize and plan code projects with clear requirements.",icon:"⌘",caps:["HTML","CSS","JavaScript","Python","Debug checklist"],notice:"Live code execution and AI coding require a secure execution environment and/or AI provider connection."},
 powers:{title:"Superpower Lab",desc:"Design special abilities for games you own or games that explicitly permit them.",icon:"⚡",caps:["Teleport","Flying","Telekinesis","Underground","Super speed"],notice:"This is for authorized game development and permitted experiences only. It does not bypass other games' protections or grant powers in arbitrary Roblox games."}
};
const homeCards=[
["assistant","✧","Master AI","Plan projects and ask the central assistant."],
["website","▣","Website Studio","Build website plans and front-end projects."],
["roblox","◈","Roblox Creator","Avatar, clothing, map and Luau workflows."],
["games","🎮","Game Creator","Create 2D and 3D game concepts."],
["cartoon","✿","Cartoon Studio","Characters, stories and animation."],
["threeD","⬡","3D Studio","3D model and environment workflows."],
["media","▧","Image & Video","Visual concepts, prompts and storyboards."],
["coding","⌘","Coding Studio","Code drafting and project planning."],
["phone","▯","Phone Assistant","Android settings guides and checklists."],
["powers","⚡","Superpower Lab","Authorized special-power game mechanics."]
];
const $=s=>document.querySelector(s);
const pages=["home","assistant","studio","projects","phone"];
let currentStudio="website";
let projects=JSON.parse(localStorage.getItem("nexoraProjects")||"[]");
function toast(t){const el=$("#toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2300)}
function go(page){
 document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
 const id=pages.includes(page)?page:"studio";
 $("#page-"+id).classList.add("active");
 document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
 $("#crumbName").textContent=page==="studio"?studios[currentStudio].title:({home:"Overview",assistant:"Master AI",projects:"My Projects",phone:"Phone Assistant"}[page]||page);
 $("#sidebar").classList.remove("open");window.scrollTo(0,0);
 if(page==="projects")renderProjects();
}
function openStudio(key){currentStudio=key;const s=studios[key];$("#studioTitle").textContent=s.title;$("#studioDescription").textContent=s.desc;$("#studioEyebrow").textContent="CREATOR WORKSPACE";$("#previewIcon").textContent=s.icon;$("#previewHeading").textContent=s.title+" workspace";$("#previewText").textContent=s.desc;$("#studioNotice").textContent=s.notice;$("#capabilityList").innerHTML=s.caps.map(x=>`<span>${x}</span>`).join("");$("#projectName").value="";$("#projectPrompt").value="";$("#referenceFile").value="";$("#fileName").textContent="No file selected. Files stay on this device in this version.";go("studio")}
function renderHome(){ $("#homeGrid").innerHTML=homeCards.map(([key,icon,title,desc])=>`<div class="feature-card" data-card="${key}"><div class="card-icon">${icon}</div><h3>${title}</h3><p>${desc}</p></div>`).join("");document.querySelectorAll("[data-card]").forEach(el=>el.onclick=()=>el.dataset.card==="assistant"||el.dataset.card==="phone"?go(el.dataset.card):openStudio(el.dataset.card));renderRecent()}
function saveProjects(){localStorage.setItem("nexoraProjects",JSON.stringify(projects))}
function renderRecent(){const box=$("#recentProjects");if(!projects.length){box.innerHTML='<p class="empty">Your saved projects will appear here.</p>';return}box.innerHTML=projects.slice(0,3).map(p=>`<div class="recent-item"><div><b>${escapeHtml(p.name)}</b><small>${escapeHtml(p.type)} · ${new Date(p.date).toLocaleDateString()}</small></div><span>✓</span></div>`).join("")}
function renderProjects(){const box=$("#allProjects");if(!projects.length){box.innerHTML='<p class="empty">No projects saved yet. Open a Studio to create your first project brief.</p>';return}box.innerHTML=projects.map((p,i)=>`<div class="project-item"><div><b>${escapeHtml(p.name)}</b><small>${escapeHtml(p.type)} · ${new Date(p.date).toLocaleString()}</small><small>${escapeHtml(p.prompt.slice(0,180))}</small></div><button class="secondary-btn" data-delete="${i}">Delete</button></div>`).join("");box.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>{projects.splice(Number(b.dataset.delete),1);saveProjects();renderProjects();renderRecent();toast("Project deleted")})}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function download(name,text){const a=document.createElement("a");const url=URL.createObjectURL(new Blob([text],{type:"text/plain"}));a.href=url;a.download=name.replace(/[^a-z0-9-_]/gi,"_")+".txt";a.click();URL.revokeObjectURL(url)}
function projectText(){return `NEXORA AI PROJECT BRIEF\nName: ${$("#projectName").value.trim()||"Untitled project"}\nStudio: ${studios[currentStudio].title}\nDate: ${new Date().toLocaleString()}\n\nDESCRIPTION\n${$("#projectPrompt").value.trim()}\n\nCAPABILITIES\n${studios[currentStudio].caps.join(", ")}\n\nNOTES\n${studios[currentStudio].notice}\n`}
$("#saveProject").onclick=()=>{const name=$("#projectName").value.trim();const prompt=$("#projectPrompt").value.trim();if(!name||!prompt)return toast("Add a project name and description first.");projects.unshift({name,prompt,type:studios[currentStudio].title,date:new Date().toISOString()});saveProjects();renderRecent();toast("Project brief saved on this device")};
$("#downloadBrief").onclick=()=>{if(!$("#projectPrompt").value.trim())return toast("Write a project description first.");download($("#projectName").value.trim()||"nexora-project",projectText());toast("Project brief downloaded")};
$("#referenceFile").onchange=e=>$("#fileName").textContent=e.target.files[0]?e.target.files[0].name+" selected (not uploaded).":"No file selected.";
document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>{const p=b.dataset.page;if(studios[p])openStudio(p);else go(p)});
document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>{const p=b.dataset.go;if(studios[p])openStudio(p);else go(p)});
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
document.querySelectorAll("[data-prompt]").forEach(b=>b.onclick=()=>{$("#chatInput").value=b.dataset.prompt;$("#chatInput").focus()});
function addMessage(role,text){const d=document.createElement("div");d.className="message "+role;const b=document.createElement("b");b.textContent=role==="bot"?"NEXORA AI":"YOU";const p=document.createElement("p");p.textContent=text;d.append(b,p);$("#chatMessages").append(d);$("#chatMessages").scrollTop=$("#chatMessages").scrollHeight}
$("#chatForm").onsubmit=async e=>{e.preventDefault();const prompt=$("#chatInput").value.trim();if(!prompt)return;$("#chatInput").value="";addMessage("user",prompt);try{const r=await fetch("/api/assistant",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});const data=await r.json();if(r.ok)addMessage("bot",data.answer);else addMessage("bot",data.detail||data.error||"AI connection is not available. You can still use the Studio project brief tools.");}catch(_){addMessage("bot","The AI server is not connected. You can still use the Studios to write and save project briefs. Run the Node.js server to enable the assistant endpoint.");}};
renderHome();
fetch("/api/health").then(r=>r.json()).then(d=>{if(!d.aiConfigured)console.info("NEXORA AI: demo mode; no provider key configured.");}).catch(()=>{});
